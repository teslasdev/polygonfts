import marketAbi from './NFTMarketplace.json';

export const MarketAddress = '0xc7C55332B75700eb9276EfB7e7FA3d54b2762c01';
export const MarketAddressABI = marketAbi.abi;
